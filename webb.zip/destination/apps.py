from django.apps import AppConfig


class DestinationConfig(AppConfig):
    name = 'destination'
